package com.rays.service03.ctl;

public interface UserDAOInt {

	public long add(UserDTO dto);
}
