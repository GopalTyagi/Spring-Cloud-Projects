package com.rays.service03.ctl;

public interface UserServiceInt {

	public long add(UserDTO dto) ;
}
